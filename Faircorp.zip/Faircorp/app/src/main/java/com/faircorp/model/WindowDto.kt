package com.faircorp.model

import com.faircorp.Status

data class WindowDto(val id: Long, val name: String, val room: RoomDto, val status: Status)