package com.faircorp

enum class Status { OPEN, CLOSED}